﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace IMDB
{
    public partial class frmConfig : Form
    {

        private frmPrincipal _frmPrincipal;

        public frmConfig(frmPrincipal parent)
        {
            InitializeComponent();
            _frmPrincipal = parent;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                Configs configs = new Configs();
                configs.local = txtPasta.Text;
                configs.update = txtUpdates.Text;
                configs.APIKey = txtKey.Text;
                configs.DownloadImg = cbDownload.Checked;

                int.TryParse(txtListWidth.Text, out int ListWidth);
                int.TryParse(txtRowHeight.Text, out int RowHeight);
                configs.listWidth = ListWidth;
                configs.rowHeight = RowHeight;

                string path = Application.StartupPath + "/config.json";
                string result = JsonConvert.SerializeObject(configs);
                File.WriteAllText(path, result);
                MessageBox.Show("Guardado.");

                if (configs.listWidth > 0)
                {
                    _frmPrincipal.dgvLista.Width = configs.listWidth;
                }
                if (configs.rowHeight > 0)
                {
                    _frmPrincipal.dgvLista.RowTemplate.Height = configs.rowHeight;
                    _frmPrincipal.dgvCast.RowTemplate.Height = configs.rowHeight;
                    _frmPrincipal.dgvDirectors.RowTemplate.Height = configs.rowHeight;
                }
                _frmPrincipal.refreshList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void frmConfig_Load(object sender, EventArgs e)
        {
            try
            {
                Configs configs = new Configs();
                if (File.Exists(Application.StartupPath + "/config.json"))
                {
                    string result = File.ReadAllText(Application.StartupPath + "/config.json");
                    configs = JsonConvert.DeserializeObject<Configs>(result);
                    txtPasta.Text = configs.local;
                    txtUpdates.Text = configs.update;
                    txtKey.Text = configs.APIKey;
                    cbDownload.Checked = configs.DownloadImg;
                    txtListWidth.Text = configs.listWidth.ToString();
                    txtRowHeight.Text = configs.rowHeight.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
