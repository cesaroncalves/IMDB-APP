﻿using System;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using System.Web;
using System.Diagnostics;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Globalization;
using System.Drawing;

namespace IMDB
{
    public partial class frmPrincipal : Form
    {
        List<Movies> moviesL;
        List<Movies> moviesL_tmp;
        Movie movie;
        Configs configs;
        List<Movies> filteredMoviesL;

        DirectoryInfo d;
        DirectoryInfo[] Files;

        string currentFolder;
        int counter;
        //bool bwTerminado;
        bool bwFullSpeed = false;

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            //foreach (TabPage item in tabControl1.TabPages)
            //{
            //    SetTabHeader(item, Color.DimGray);
            //}
            //tabControl1.DrawMode = TabDrawMode.OwnerDrawFixed;

            moviesL_tmp = new List<Movies>();

            if (File.Exists(Application.StartupPath + "/config.json"))
            {
                configs = new Configs();
                string result = File.ReadAllText(Application.StartupPath + "/config.json");
                configs = JsonConvert.DeserializeObject<Configs>(result);

                try
                {
                    if (configs.listWidth > 0)
                    {
                        dgvLista.Width = configs.listWidth;
                    }
                    if (configs.rowHeight > 0)
                    {
                        dgvLista.RowTemplate.Height = configs.rowHeight;
                        dgvCast.RowTemplate.Height = configs.rowHeight;
                        dgvDirectors.RowTemplate.Height = configs.rowHeight;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

            if (File.Exists(Application.StartupPath + "\\IMDB_old.exe")) { File.Delete(Application.StartupPath + "\\IMDB_old.exe"); }

            StartLoad();
            checkUpdates();
            bwFullSpeed = false;
            backgroundWorker.RunWorkerAsync();
        }

        //private Dictionary<TabPage, Color> TabColors = new Dictionary<TabPage, Color>();
        //private void SetTabHeader(TabPage page, Color color)
        //{
        //    TabColors[page] = color;
        //    tabControl1.Invalidate();
        //}

        private void tabControl1_DrawItem(object sender, DrawItemEventArgs e)
        {
            //using (Brush br = new SolidBrush(TabColors[tabControl1.TabPages[e.Index]]))
            //{
            //    e.Graphics.FillRectangle(br, e.Bounds);
            //    SizeF sz = e.Graphics.MeasureString(tabControl1.TabPages[e.Index].Text, e.Font);
            //    e.Graphics.DrawString(tabControl1.TabPages[e.Index].Text, e.Font, Brushes.Black, e.Bounds.Left + (e.Bounds.Width - sz.Width) / 2, e.Bounds.Top + (e.Bounds.Height - sz.Height) / 2 + 1);

            //    Rectangle rect = e.Bounds;
            //    rect.Offset(0, 1);
            //    rect.Inflate(0, -1);
            //    e.Graphics.DrawRectangle(Pens.DarkGray, rect);
            //    e.DrawFocusRectangle();
            //}
            try
            {
                Brush BackBrush = new SolidBrush(Color.Transparent);

                e.Graphics.FillRectangle(BackBrush, e.Bounds);

                BackBrush.Dispose();


                TabPage CurrentTab = this.tabControl1.TabPages[e.Index];
                Rectangle ItemRect = this.tabControl1.GetTabRect(e.Index);
                SolidBrush FillBrush;
                SolidBrush TextBrush;
                StringFormat sf = new StringFormat();

                if (e.State == DrawItemState.Selected)
                {
                    FillBrush = new SolidBrush(Color.Black);
                    TextBrush = new SolidBrush(Color.WhiteSmoke);
                    TextBrush.Color = Color.White;
                }
                else
                {
                    FillBrush = new SolidBrush(Color.DimGray);
                    TextBrush = new SolidBrush(Color.WhiteSmoke);
                    TextBrush.Color = Color.WhiteSmoke;
                }

                

                //Next we'll paint the TabItem with our Fill Brush
                e.Graphics.FillRectangle(FillBrush, ItemRect);

                Font objfont;
                objfont = new Font(e.Font.Name, e.Font.Size);

                RectangleF objrectangleF;
                //objrectangleF = CType(ItemRect, RectangleF)
                objrectangleF = (ItemRect != null) ? ((RectangleF)ItemRect) : default(RectangleF);

                //sf.Alignment = System.Drawing.StringAlignment.Center
                //sf.LineAlignment = System.Drawing.StringAlignment.Center

                e.Graphics.DrawString(CurrentTab.Text, objfont, TextBrush, objrectangleF, sf);

                //Finally, we should Dispose of our brushes.
                FillBrush.Dispose();
                TextBrush.Dispose();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void checkUpdates()
        {
            await Task.Run(() => {
                try
                {
                    if (configs.update != null)
                    {
                        if (File.Exists(configs.update + "\\IMDB.exe"))
                        {
                            if (File.GetLastWriteTime(Application.StartupPath + "\\IMDB.exe") < File.GetLastWriteTime(configs.update + "\\IMDB.exe"))
                            {
                                btnUpdate1.Text = "Atulização Disponível";
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            });
        }

        private void btnUpdate2_Click(object sender, EventArgs e)
        {
            try
            {
                File.Move(Application.StartupPath + "\\IMDB.exe", Application.StartupPath + "\\IMDB_old.exe");
                File.Copy(configs.update + "\\IMDB.exe", Application.StartupPath + "\\IMDB.exe");
                MessageBox.Show("Reinicie o programa.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void StartLoad()
        {
            await Task.Run(() =>
            {
                try
                {
                    moviesL = new List<Movies>();

                    if (File.Exists(Application.StartupPath + "/config.json"))
                    {
                        Invoke((MethodInvoker)delegate {
                            carregarLista(configs.local);
                        });

                        NetworkCredential theNetworkCredential = new NetworkCredential(@"osmc", "osmc"); // This isn't working as intended
                        CredentialCache theNetCache = new CredentialCache();
                        theNetCache.Add(new Uri(@"\\OSMC"), "Basic", theNetworkCredential);
                        string[] theFolders = Directory.GetDirectories(configs.local);
                    }

                    if (File.Exists(configs.local + "//SavedList.json"))
                    {
                        string result = File.ReadAllText(configs.local + "//SavedList.json");
                        moviesL = JsonConvert.DeserializeObject<List<Movies>>(result);
                    }

                    //bwTerminado = true;

                    Invoke((MethodInvoker)delegate {
                        bwProgress.Visible = true;
                        toolStripTextBox1.Visible = true;
                        toolStripMenuItem1.Visible = true;
                        toolStripComboBox1.Visible = true;

                        dgvLista_CellEnter(this, null);
                    });
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            });
        }


        private void carregarLista(string local)
        {
            try
            {
                d = new DirectoryInfo(local);
                Files = d.GetDirectories().OrderBy(p => p.CreationTimeUtc).ToArray();

                foreach (DirectoryInfo file in Files)
                {
                    Console.WriteLine(file.Name);
                    if (file.Name == "...")
                    {
                        dgvLista.Rows.Add(file, Properties.Resources.back);
                    }

                    if (file.Name.Contains("(") || file.Name.Contains(")"))
                    {
                        dgvLista.Rows.Add(file, Properties.Resources.video);
                    }

                    if (!file.Name.Contains("(") && !file.Name.Contains(")"))
                    {
                        dgvLista.Rows.Add(file, Properties.Resources.folder);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            Console.WriteLine("--------------------------");
            Console.WriteLine("--------------------------");
        }

        //Adciona filme á lista
        private void addItemL(string folder, bool fileFolder)
        {
            try
            {
                Movies movies = new Movies();
                string currentFolder2 = "";
                int i = 0;

                if (fileFolder)
                {
                    if (File.Exists(configs.local + "//" + folder + currentFolder2 + "//info.json"))
                    {
                        movies.folder = folder;
                        movies.fileFolder = fileFolder;
                        string strJSON = File.ReadAllText(configs.local + "//" + folder + currentFolder2 + "//info.json");
                        movies.movie = JsonConvert.DeserializeObject<Movie>(strJSON);
                    }
                    if (movies.movie != null)
                    {
                        movies.movie.similars = null;
                        moviesL_tmp.Add(movies);
                        counter = counter + 1;
                        backgroundWorker.ReportProgress(counter);
                    }
                }
                else
                {
                    d = new DirectoryInfo(configs.local + "//" + folder);
                    Files = d.GetDirectories();


                    foreach (DirectoryInfo file in Files)
                    {
                        movies = new Movies();
                        i++;
                        currentFolder2 = "//" + file.Name;
                        if (File.Exists(configs.local + "//" + folder + currentFolder2 + "//info.json"))
                        {
                            movies.folder = folder + currentFolder2;
                            movies.fileFolder = fileFolder;
                            string strJSON = File.ReadAllText(configs.local + "//" + folder + currentFolder2 + "//info.json");
                            movies.movie = JsonConvert.DeserializeObject<Movie>(strJSON);
                        }
                        counter = counter + 1;
                        if (movies.movie != null)
                        {
                            movies.movie.similars = null;
                            moviesL_tmp.Add(movies);
                            Console.WriteLine(movies.movie.title);
                            Console.Write(i.ToString() + " ");
                            Console.WriteLine(movies.folder);
                            backgroundWorker.ReportProgress(counter);
                        }

                        currentFolder2 = "";
                    }
                }

                File.WriteAllText(Application.StartupPath + "//SavedLists.txt", JsonConvert.SerializeObject(moviesL));

                currentFolder2 = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < dgvLista.RowCount; i++)
                {
                    dgvLista.Rows[i].Selected = false;
                    dgvLista.Rows[i].Selected = true;
                    dgvLista.Refresh();
                    Application.DoEvents();

                    try
                    {
                        var cell = this.dgvLista.SelectedCells[0];
                        var row = this.dgvLista.Rows[cell.RowIndex];
                        string value = row.Cells[0].Value.ToString();

                        string[] collection = value.Split('(');

                        string nome = collection[0];

                        collection = collection[1].Split(')');

                        string ano = collection[0];

                        if (File.Exists(configs.local + "//" + value + currentFolder + "//info.json"))
                        {
                            string strJSON = File.ReadAllText(configs.local + "//" + value + currentFolder + "//info.json");
                            movie = JsonConvert.DeserializeObject<Movie>(strJSON);
                            preencheInfo(value);
                        }
                        else
                        {
                            getMovie(nome, ano, value);
                        }

                        Application.DoEvents();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void getMovie(string nome, string ano, string folder)
        {
            try
            {

                title.Text = "Download . . .";

                if (configs.APIKey != "" || configs.APIKey != null)
                {
                    await Task.Run(() =>
                    {
                        try
                        {
                            RESTClient rClient = new RESTClient();
                            WebClient client = new WebClient();

                            string httpNomeFilme = Uri.EscapeDataString(nome + "" + ano);

                            //Pesquisa o filme

                            rClient.endPoint = "https://imdb-api.com/en/API/SearchMovie/" + configs.APIKey + "/" + httpNomeFilme;

                            string strJSON = string.Empty;

                            strJSON = rClient.makeRequest();

                            SearchData data = JsonConvert.DeserializeObject<SearchData>(strJSON);

                            debugOutput(strJSON);

                            //Busca a info do filme

                            if (data.Results.Count == 0)
                            {
                                if (!File.Exists(configs.local + "//" + folder + currentFolder + "//poster.jpg"))
                                {
                                    pbPoster.Image = Properties.Resources.NoImage;
                                }

                                AppendTextBox("Não encontrado . . .");

                            }
                            else
                            {

                                rClient.endPoint = "https://imdb-api.com/en/API/Title/" + configs.APIKey + "/" + data.Results[0].Id;

                                strJSON = "";

                                strJSON = rClient.makeRequest();

                                movie = JsonConvert.DeserializeObject<Movie>(strJSON);

                                if (configs.DownloadImg)
                                {
                                    File.WriteAllText(configs.local + currentFolder + "//" + folder + "//info.json", strJSON);
                                    pbPoster.Image = Properties.Resources.download;
                                    client.DownloadFile(new Uri(movie.image), configs.local + currentFolder + "//" + folder + "//poster.jpg");
                                    //System.Threading.Thread.Sleep(2000);
                                    pbPoster.Load(configs.local + currentFolder + "//" + folder + "//poster.jpg");
                                    Application.DoEvents();
                                }

                                preencheInfo(folder);
                            }
                            //txtResponse.Text = "";
                            //debugOutput(strJSON);
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine(ex.Message);
                            Debug.WriteLine(ex.Data);
                        }

                    });
                }
                else
                {
                    MessageBox.Show("No IMDB Key Found");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void AppendTextBox(string value)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(AppendTextBox), new object[] { value });
                return;
            }
            title.Text = value;
        }

        private void preencheInfo(string folder)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(preencheInfo), new object[] { folder });
                return;
            }

            try
            {   
                title.Text = movie.title;
                fullTitle.Text = movie.title;
                year.Text = movie.year;
                releaseDate.Text = movie.releaseDate;
                runtimeStr.Text = movie.runtimeStr;
                imDbRating.Text = movie.imDbRating;
                metacriticRating.Text = movie.metacriticRating;
                genres.Text = movie.genres;
                stars.Text = movie.stars;
                txtPlot.Text = movie.plot;
                txtIMDBID.Text = movie.id;

                dgvCast.Rows.Clear();

                foreach (var item in movie.actorList)
                {
                    dgvCast.Rows.Add(item.name, item.asCharacter);
                }
                
                dgvDirectors.Rows.Clear();

                if (movie.directorList != null)
                {
                    foreach (var item in movie.directorList)
                    {
                        dgvDirectors.Rows.Add("Director", item.name);
                    }
                }
                if (movie.writerList != null)
                {
                    foreach (var item in movie.writerList)
                    {
                        dgvDirectors.Rows.Add("Writer", item.name);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


            //DirectoryInfo d = new DirectoryInfo(configs.local + currentFolder + "//" + folder);
            //FileInfo[] Files = d.GetFiles("*.*"); ;
            //dgvFolder.Rows.Clear();

            //foreach (FileInfo file in Files)
            //{
            //    dgvFolder.Rows.Add(file.Name);
            //}

            //if (File.Exists(configs.local + currentFolder + "//" + folder + "//poster.jpg"))
            //{
            //    pbPoster.LoadAsync(configs.local + currentFolder + "//" + folder + "//poster.jpg");
            //}
            //else
            //{
            //    pbPoster.LoadAsync(movie.image);
            //}            
        }

        private void preencheInfo(Movies m)
        {
            string folder = m.folder;

            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(preencheInfo), new object[] { folder });
                return;
            }
            else if (m.movie != null)
            {
                try
                {
                    title.Text = m.movie.title;
                    fullTitle.Text = m.movie.title;
                    year.Text = m.movie.year;
                    releaseDate.Text = m.movie.releaseDate;
                    runtimeStr.Text = m.movie.runtimeStr;
                    imDbRating.Text = m.movie.imDbRating;
                    metacriticRating.Text = m.movie.metacriticRating;
                    genres.Text = m.movie.genres;
                    stars.Text = m.movie.stars;
                    txtPlot.Text = m.movie.plot;
                    txtIMDBID.Text = m.movie.id;

                    dgvCast.Rows.Clear();

                    foreach (var item in m.movie.actorList)
                    {
                        dgvCast.Rows.Add(item.name, item.asCharacter);
                    }

                    dgvDirectors.Rows.Clear();

                    if (m.movie.directorList != null)
                    {
                        foreach (var item in m.movie.directorList)
                        {
                            dgvDirectors.Rows.Add("Director", item.name);
                        }
                    }
                    if (m.movie.writerList != null)
                    {
                        foreach (var item in m.movie.writerList)
                        {
                            dgvDirectors.Rows.Add("Writer", item.name);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private Movies getMovie(string directory)
        {
            try
            {
                Movies result = new Movies();

                if (moviesL != null)
                {
                    foreach (var item in moviesL)
                    {
                        if (item.folder == directory)
                            result = item;
                        else
                        {
                            string[] itemL = item.folder.Split('/');
                            if (itemL.Count() > 1)
                            {
                                if (itemL[1] == directory)
                                {
                                    result = item;
                                }
                                else if (itemL[2] == directory)
                                {
                                    result = item;
                                }
                            }
                        }
                    }

                    if (result.movie != null)
                    {
                        return result;
                    }
                    else
                    {
                        return null;
                    }
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        private void debugOutput(string strDebugText)
        {
            try
            {
                System.Diagnostics.Debug.Write(strDebugText + Environment.NewLine);
                txtResponse.Text = txtResponse.Text + strDebugText + Environment.NewLine;
                txtResponse.SelectionStart = txtResponse.TextLength;
                txtResponse.ScrollToCaret();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.Message, ToString() + Environment.NewLine);
            }
        }

        private void configToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConfig frmConfig = new frmConfig(this);
            frmConfig.ShowDialog();
        }

        private void dgvLista_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                title.Text = "";
                fullTitle.Text = "";
                year.Text = "";
                releaseDate.Text = "";
                runtimeStr.Text = "";
                imDbRating.Text = "";
                metacriticRating.Text = "";
                genres.Text = "";
                stars.Text = "";
                txtPlot.Text = "";
                txtIMDBID.Text = "";
                dgvCast.Rows.Clear();
                dgvDirectors.Rows.Clear();
                //dgvFolder.Rows.Clear();

                pbPoster.Image = Properties.Resources.loading;

                var cell = this.dgvLista.SelectedCells[0];
                var row = this.dgvLista.Rows[cell.RowIndex];
                string value = row.Cells[0].Value.ToString();


                TryLoadPoster(configs.local + currentFolder + "\\" + value);

                //if (value.Contains("..."))
                if (value == "...")
                {
                    pbPoster.Image = Properties.Resources.back;
                    title.Text = "Voltar . . .";
                }
                else if (value.Contains("(") && value.Contains(")"))
                {
                    string[] collection = value.Split('(');

                    string nome = collection[0];
                    nome = nome.Replace("EXTENDED", "");
                    nome = nome.Replace("Extended", "");
                    nome = nome.Replace("UNRATED", "");
                    nome = nome.Replace("DIRECTORS CUT", "");
                    

                    collection = collection[1].Split(')');

                    string ano = collection[0];

                    Movies m = new Movies();
                    m = getMovie(value);

                    if (m != null)
                    {
                        preencheInfo(m);
                    }
                    else
                    {
                        if (File.Exists(configs.local + currentFolder + "//" + value + "//info.json"))
                        {
                            string strJSON = File.ReadAllText(configs.local + currentFolder + "//" + value + "//info.json");
                            movie = JsonConvert.DeserializeObject<Movie>(strJSON);
                            preencheInfo(value);
                        }
                        else
                        {
                            getMovie(nome, ano, value);
                        }
                    }
                }
                else
                {
                    if (File.Exists(configs.local + currentFolder + "//poster.jpg") || File.Exists(configs.local + currentFolder + "//poster.png"))
                    {
                        //pbPoster.LoadAsync(configs.local + currentFolder + "\\poster.jpg");
                        TryLoadPoster(configs.local + currentFolder);
                    }
                    else
                    {
                        pbPoster.Image = Properties.Resources.folder;
                    }
                    title.Text = "Abrir Pasta.";
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Debug.WriteLine(ex.Data);
            }
            
        }

        private async void TryLoadPoster(string value)
        {
            await Task.Run(() => {
                try
                {
                    if (File.Exists(value + "\\poster.jpg"))
                    {
                        pbPoster.LoadAsync(value + "\\poster.jpg");
                    }
                    else if (File.Exists(value + "\\poster.png"))
                    {
                        pbPoster.LoadAsync(value + "\\poster.png");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            });
        }

        private void dgvLista_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                var cell = this.dgvLista.SelectedCells[0];
                var row = this.dgvLista.Rows[cell.RowIndex];
                string value = row.Cells[0].Value.ToString();

                if (value.Contains("(") && value.Contains(")"))
                {
                    if (Directory.Exists(configs.local + currentFolder + "//" + value))
                    {
                        ProcessStartInfo startInfo = new ProcessStartInfo
                        {
                            Arguments = configs.local + currentFolder + "//" + value,
                            FileName = "explorer.exe"
                        };
                        Process.Start(configs.local + currentFolder + "//" + value);
                    }
                    else
                    {
                        MessageBox.Show(string.Format("{0} Directory does not exist!", configs.local + currentFolder + "//" + value));
                    }
                }
                else if (value == "...")
                {
                    dgvLista.Rows.Clear();
                    currentFolder = "";
                    carregarLista(configs.local);
                }
                else
                {
                    dgvLista.Rows.Clear();
                    dgvLista.Rows.Add("...", Properties.Resources.back);
                    pbPoster.Image = Properties.Resources.back;
                    currentFolder = "//" + value;
                    carregarLista(configs.local + "//" + value);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            counter = 0;
            //bwTerminado = false;
            d = new DirectoryInfo(configs.local);
            Files = d.GetDirectories();

            foreach (DirectoryInfo file in Files)
            {
                if (bwFullSpeed == false)
                    System.Threading.Thread.Sleep(500); //Para não ocupar o disco completamente

                if (file.Name == "...")
                {
                    //dgvLista.Rows.Add(file, Properties.Resources.back);
                }

                if (file.Name.Contains("(") || file.Name.Contains(")"))
                {
                    Console.WriteLine(file.Name);
                    addItemL(file.Name, true);
                }

                if (!file.Name.Contains("(") && !file.Name.Contains(")"))
                {
                    Console.WriteLine(file.Name);
                    addItemL(file.Name, false);
                }
            }


            if (moviesL != moviesL_tmp)
            {
                moviesL = moviesL_tmp;
                File.Delete(configs.local + "//SavedList.json");
                File.WriteAllText(configs.local + "//SavedList.json", string.Empty);
                File.WriteAllText(configs.local + "//SavedList.json", JsonConvert.SerializeObject(moviesL));
            }

            //bwTerminado = true;

            //bwProgress.Text = bwProgress.Text + " : Terminado";
        }

        private void backgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            bwProgress.Text = counter.ToString();
        }

        private void toolStripTextBox1_KeyUp(object sender, KeyEventArgs e)
        {
            
        }

        private void pbPoster_Click(object sender, EventArgs e)
        {
            frmCover frmCover = new frmCover();
            frmCover.cover = pbPoster.ImageLocation;
            frmCover.Show();
        }

        private void btnDesbloquearPesquisa_Click(object sender, EventArgs e)
        {
            
        }

        private void desbloquearPesquisaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bwProgress.Visible = true;
            bwFullSpeed = true;
            //moviesL_tmp.Clear();
            //backgroundWorker.RunWorkerAsync();
        }

        private void toolStripComboBox2_TextChanged(object sender, EventArgs e)
        {
            refreshList();
        }

        public void refreshList()
        {
            dgvLista.Rows.Clear();

            if (currentFolder != "")
            {
                dgvLista.Rows.Add("...", Properties.Resources.back);
            }

            if (toolStripComboBox2.SelectedIndex == 0)
            {
                Files = d.GetDirectories().OrderBy(p => p.CreationTimeUtc).ToArray();

                foreach (DirectoryInfo file in Files)
                {
                    Console.WriteLine(file.Name);
                    if (file.Name == "...")
                    {
                        dgvLista.Rows.Add(file, Properties.Resources.back);
                    }

                    if (file.Name.Contains("(") || file.Name.Contains(")"))
                    {
                        dgvLista.Rows.Add(file, Properties.Resources.video);
                    }

                    if (!file.Name.Contains("(") && !file.Name.Contains(")"))
                    {
                        dgvLista.Rows.Add(file, Properties.Resources.folder);
                    }

                }
            }
            if (toolStripComboBox2.SelectedIndex == 1)
            {
                Files = d.GetDirectories().OrderBy(p => p.FullName).ToArray();

                foreach (DirectoryInfo file in Files)
                {
                    Console.WriteLine(file.Name);
                    if (file.Name == "...")
                    {
                        dgvLista.Rows.Add(file, Properties.Resources.back);
                    }

                    if (file.Name.Contains("(") || file.Name.Contains(")"))
                    {
                        dgvLista.Rows.Add(file, Properties.Resources.video);
                    }

                    if (!file.Name.Contains("(") && !file.Name.Contains(")"))
                    {
                        dgvLista.Rows.Add(file, Properties.Resources.folder);
                    }

                }
            }
            if (toolStripComboBox2.SelectedIndex == 2)
            {
                Files = d.GetDirectories().OrderBy(p => p.LastAccessTimeUtc).ToArray();

                foreach (DirectoryInfo file in Files)
                {
                    Console.WriteLine(file.Name);
                    if (file.Name == "...")
                    {
                        dgvLista.Rows.Add(file, Properties.Resources.back);
                    }

                    if (file.Name.Contains("(") || file.Name.Contains(")"))
                    {
                        dgvLista.Rows.Add(file, Properties.Resources.video);
                    }

                    if (!file.Name.Contains("(") && !file.Name.Contains(")"))
                    {
                        dgvLista.Rows.Add(file, Properties.Resources.folder);
                    }

                }
            }
        }

        private void toolStripTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                currentFolder = "";
                if (toolStripTextBox1.Text != "")
                {
                    if (moviesL != null)
                    {
                        string debugMovie = "";
                        filteredMoviesL = new List<Movies>();
                        try
                        {
                            if (toolStripComboBox1.Text == "Name")
                            {
                                //foreach (var m in moviesL.Where(m => (m.movie.title.ToUpper().Contains(toolStripTextBox1.Text.ToUpper()))))
                                //{
                                //    filteredMoviesL.Add(m);   
                                //}


                                foreach (var m in moviesL)
                                {
                                    if (m.movie.title == null)
                                    {
                                        Debug.WriteLine(m.folder);
                                    }
                                    else
                                    {
                                        if (m.movie.title.ToUpper().Contains(toolStripTextBox1.Text.ToUpper()))
                                        {
                                            filteredMoviesL.Add(m);
                                        }
                                    }
                                }

                            }

                            if (toolStripComboBox1.Text == "Actor/Actress")
                            {
                                //List<string> actors = new List<string>();
                                foreach (var item in moviesL)
                                {
                                    bool added = false;
                                    //Console.WriteLine(item.movie.title);
                                    if (item.movie == null)
                                    {
                                        Console.WriteLine(item.folder);
                                    }
                                    else
                                    {
                                        if (item.movie.actorList != null)
                                        {
                                            foreach (var actor in item.movie.actorList)
                                            {
                                                if (actor.name.ToUpper().Contains(toolStripTextBox1.Text.ToUpper()))
                                                {
                                                    //Console.WriteLine(actor.name);
                                                    filteredMoviesL.Add(item);
                                                    added = true;
                                                }
                                            }
                                            if (!added)
                                            {
                                                if (item.movie.stars.ToUpper().Contains(toolStripTextBox1.Text.ToUpper()))
                                                {
                                                    filteredMoviesL.Add(item);
                                                }
                                            }
                                            added = false;
                                        }
                                    }
                                }
                            }

                            if (toolStripComboBox1.Text == "Writer")
                            {
                                //List<string> writers = new List<string>();
                                foreach (var item in moviesL)
                                {
                                    //Console.WriteLine(item.movie.title);
                                    if (item.movie == null)
                                    {
                                        Console.WriteLine(item.folder);
                                    }
                                    else
                                    {
                                        if (item.movie.writerList != null)
                                        {
                                            foreach (var writer in item.movie.writerList)
                                            {
                                                if (writer.name.ToUpper().Contains(toolStripTextBox1.Text.ToUpper()))
                                                {
                                                    //Console.WriteLine(actor.name);
                                                    filteredMoviesL.Add(item);
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            if (toolStripComboBox1.Text == "Director")
                            {
                                //List<string> directors = new List<string>();
                                foreach (var item in moviesL)
                                {
                                    //Console.WriteLine(item.movie.title);
                                    if (item.movie == null)
                                    {
                                        Console.WriteLine(item.folder);
                                    }
                                    else
                                    {
                                        if (item.movie.directorList != null)
                                        {
                                            foreach (var director in item.movie.directorList)
                                            {
                                                if (director.name.ToUpper().Contains(toolStripTextBox1.Text.ToUpper()))
                                                {
                                                    //Console.WriteLine(actor.name);
                                                    filteredMoviesL.Add(item);
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            if (toolStripComboBox1.Text == "Genre")
                            {
                                //foreach (var m in moviesL.Where(m => (m.movie.genres.ToUpper().Contains(toolStripTextBox1.Text.ToUpper()))))
                                //{
                                //    filteredMoviesL.Add(m);
                                //}

                                foreach (var m in moviesL)
                                {
                                    if (m.movie != null)
                                    {
                                        if (m.movie.genres != null)
                                        {
                                            if (m.movie.genres.ToUpper().Contains(toolStripTextBox1.Text.ToUpper()))
                                            {
                                                filteredMoviesL.Add(m);
                                            }
                                        }
                                    }   
                                }
                            }

                            if (toolStripComboBox1.Text == "Year")
                            {
                                //foreach (var m in moviesL.Where(m => (m.movie.year.Contains(toolStripTextBox1.Text))))
                                //{
                                //    filteredMoviesL.Add(m);
                                //}

                                foreach (var m in moviesL)
                                {
                                    if (m.movie != null)
                                    {
                                        if (m.movie.year != null)
                                        {
                                            if ((m.movie.year.Contains(toolStripTextBox1.Text)))
                                            {
                                                filteredMoviesL.Add(m);
                                            }
                                        }
                                    }
                                }
                            }

                            if (toolStripComboBox1.Text == "Ranking Above")

                            {
                                if (double.TryParse(toolStripTextBox1.Text.Replace('.', ','), out double n))
                                {
                                    //foreach (var m in moviesL.Where(m => (Convert.ToDouble(m.movie.imDbRating.Replace('.', ',')) >= n)))
                                    //{
                                    //    filteredMoviesL.Add(m);
                                    //}

                                    foreach (var m in moviesL)
                                    {
                                        if (m.movie != null)
                                        {
                                            debugMovie = m.name;
                                            if (m.movie.imDbRating != null && m.movie.imDbRating != "")
                                            {
                                                debugMovie = m.name;
                                                if ((Convert.ToDouble(m.movie.imDbRating.Replace('.', ',')) >= n))
                                                {
                                                    filteredMoviesL.Add(m);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Data);
                            Console.WriteLine(ex.Source);
                            Console.WriteLine(ex.Message);
                            Console.WriteLine("Erro no : " + debugMovie);
                        }

                        dgvLista.Rows.Clear();
                        foreach (var m in filteredMoviesL)
                        {
                            dgvLista.Rows.Add(m.folder, Properties.Resources.video);
                        }
                    }
                }
                else
                {
                    dgvLista.Rows.Clear();
                    carregarLista(configs.local);
                }
            }
        }

        private void dgvLista_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.End)
            {
                dgvLista.ClearSelection();
                int nRow = dgvLista.Rows.Count - 1;
                dgvLista.Rows[nRow].Selected = true;
                dgvLista.FirstDisplayedScrollingRowIndex = nRow;
            }
        }
        
        private void dgvLista_KeyUp(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.End)
            {
                dgvLista.ClearSelection();
                int nRow = dgvLista.Rows.Count - 1;
                dgvLista.Rows[nRow].Selected = true;
                dgvLista.Rows[nRow].Cells[0].Selected = true;
                dgvLista.CurrentCell = dgvLista.Rows[nRow].Cells[0];
                dgvLista.FirstDisplayedScrollingRowIndex = nRow;
            }
            else if (e.KeyCode == Keys.Home)
            {
                dgvLista.ClearSelection();
                int nRow = 0;
                dgvLista.Rows[nRow].Selected = true;
                dgvLista.Rows[nRow].Cells[0].Selected = true;
                dgvLista.CurrentCell = dgvLista.Rows[nRow].Cells[0];
                dgvLista.FirstDisplayedScrollingRowIndex = nRow;
            }
        }

        private void backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            toolStripTextBox1.Visible = true;
            toolStripMenuItem1.Visible = true;
            toolStripComboBox1.Visible = true;

            bwFullSpeed = false;
            moviesL_tmp.Clear();

            backgroundWorker.RunWorkerAsync(); // restart the run
        }

        private void dgvCast_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Clipboard.SetText(dgvCast.SelectedCells[0].Value.ToString());
        }

        private void dgvDirectors_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Clipboard.SetText(dgvDirectors.SelectedCells[1].Value.ToString());
        }

        private void dgvLista_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                DataGridViewCellEventArgs _e = new DataGridViewCellEventArgs(0, dgvLista.SelectedRows[0].Index);
                dgvLista_CellDoubleClick(this, _e);
            }
        }

        private async void btnDownloadFID_Click(object sender, EventArgs e)
        {
            await Task.Run(() =>
            {
                try
                {
                    DataGridViewCell cell = this.dgvLista.SelectedCells[0];
                    DataGridViewRow row = this.dgvLista.Rows[cell.RowIndex];
                    string value = row.Cells[0].Value.ToString();

                    RESTClient rClient = new RESTClient();
                    WebClient client = new WebClient();

                    string strJSON = string.Empty;

                    rClient.endPoint = @"https://imdb-api.com/en/API/Title/" + configs.APIKey + @"/" + txtIMDBID.Text;

                    strJSON = rClient.makeRequest();
                    movie = JsonConvert.DeserializeObject<Movie>(strJSON);

                    if (configs.DownloadImg)
                    {
                        File.WriteAllText(configs.local + currentFolder + "//" + value + "//info.json", strJSON);
                        Invoke((MethodInvoker)delegate {
                            pbPoster.Image = Properties.Resources.download;
                            pbPoster.Load(configs.local + "//default.png");
                            //client.DownloadFileAsync(new Uri(movie.image), configs.local + currentFolder + "//" + value + "//poster.jpg");
                            client.DownloadFile(new Uri(movie.image), configs.local + currentFolder + "//" + value + "//poster.jpg");
                            System.Threading.Thread.Sleep(1000);
                            pbPoster.Load(configs.local + currentFolder + "//" + value + "//poster.jpg");
                            Application.DoEvents();
                        });
                    }
                    Invoke((MethodInvoker)delegate {
                        txtIMDBID.Text = "";
                    });
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            });
        }

        private void downloadSubtitlesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var cell = this.dgvLista.SelectedCells[0];
            var row = this.dgvLista.Rows[cell.RowIndex];
            string value = row.Cells[0].Value.ToString();
            string nome = "";
            string ano = "";

            TryLoadPoster(configs.local + currentFolder + "\\" + value);

            //if (value.Contains("..."))
            if (value == "...")
            {
                pbPoster.Image = Properties.Resources.back;
                title.Text = "Voltar . . .";
            }
            else if (value.Contains("(") && value.Contains(")"))
            {
                string[] collection = value.Split('(');

                nome = collection[0];
                nome = nome.Replace("EXTENDED", "");
                nome = nome.Replace("Extended", "");
                nome = nome.Replace("UNRATED", "");
                nome = nome.Replace("DIRECTORS CUT", "");

                collection = collection[1].Split(')');

                ano = collection[0];
            }

            frmDownloadSubtitles frmDownloadSubtitles = new frmDownloadSubtitles();
            frmDownloadSubtitles.path = configs.local + currentFolder + "//" + currentFolder;
            frmDownloadSubtitles.name = nome;
            frmDownloadSubtitles.ano = ano;
            frmDownloadSubtitles.ShowDialog();
        }
    }

    public enum httpVerb
    {
        GET,
        POST,
        PUT,
        DELETE
    }

    class RESTClient
    {
        public string endPoint { get; set; }
        public httpVerb httpMethod { get; set; }

        //Default Constructor
        public RESTClient()
        {
            endPoint = "";
            httpMethod = httpVerb.GET;

        }

        public string makeRequest()
        {
            string strResponseValue = string.Empty;

            var request = (HttpWebRequest)WebRequest.Create(endPoint);

            request.Method = httpMethod.ToString();

            HttpWebResponse response = null;

            try
            {
                response = (HttpWebResponse)request.GetResponse();


                //Proecess the resppnse stream... (could be JSON, XML or HTML etc..._

                using (Stream responseStream = response.GetResponseStream())
                {
                    if (responseStream != null)
                    {
                        using (StreamReader reader = new StreamReader(responseStream))
                        {
                            strResponseValue = reader.ReadToEnd();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //We catch non Http 200 responses here.
                strResponseValue = "{\"errorMessages\":[\"" + ex.Message.ToString() + "\"],\"errors\":{}}";
            }
            finally
            {
                if (response != null)
                {
                    ((IDisposable)response).Dispose();
                }
            }

            return strResponseValue;

        }
    }
}


