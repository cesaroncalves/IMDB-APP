﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMDB
{
    public partial class frmDownloadSubtitles : Form
    {
        public string path;
        public string name;
        public string ano;

        public frmDownloadSubtitles()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmDownloadSubtitles_Load(object sender, EventArgs e)
        {

        }

        private async void getSubtitles(string nome, string ano, string folder)
        {
            try
            {
                    await Task.Run(() =>
                    {
                        try
                        {
                            RESTClient rClient = new RESTClient();
                            WebClient client = new WebClient();

                            string httpNomeFilme = Uri.EscapeDataString(nome + "" + ano);

                            //Pesquisa o filme

                            rClient.endPoint = "https://imdb-api.com/en/API/SearchMovie/" + configs.APIKey + "/" + httpNomeFilme;

                            string strJSON = string.Empty;

                            strJSON = rClient.makeRequest();

                            SearchData data = JsonConvert.DeserializeObject<SearchData>(strJSON);

                            debugOutput(strJSON);

                            //Busca a info do filme

                            if (data.Results.Count == 0)
                            {
                                if (!File.Exists(configs.local + "//" + folder + currentFolder + "//poster.jpg"))
                                {
                                    pbPoster.Image = Properties.Resources.NoImage;
                                }

                                AppendTextBox("Não encontrado . . .");

                            }
                            else
                            {
                                //IWewhNt24Mrn1jlt0luiRNrxW11YY2za
                                rClient.endPoint = "https://imdb-api.com/en/API/Title/" + configs.APIKey + "/" + data.Results[0].Id;

                                strJSON = "";

                                strJSON = rClient.makeRequest();

                                movie = JsonConvert.DeserializeObject<Movie>(strJSON);

                                if (configs.DownloadImg)
                                {
                                    File.WriteAllText(configs.local + currentFolder + "//" + folder + "//info.json", strJSON);
                                    pbPoster.Image = Properties.Resources.download;
                                    client.DownloadFile(new Uri(movie.image), configs.local + currentFolder + "//" + folder + "//poster.jpg");
                                    //System.Threading.Thread.Sleep(2000);
                                    pbPoster.Load(configs.local + currentFolder + "//" + folder + "//poster.jpg");
                                    Application.DoEvents();
                                }

                            }
                            //txtResponse.Text = "";
                            //debugOutput(strJSON);
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine(ex.Message);
                            Debug.WriteLine(ex.Data);
                        }

                    });
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void debugOutput(string strDebugText)
        {
            try
            {
                System.Diagnostics.Debug.Write(strDebugText + Environment.NewLine);
                txtResponse.Text = txtResponse.Text + strDebugText + Environment.NewLine;
                txtResponse.SelectionStart = txtResponse.TextLength;
                txtResponse.ScrollToCaret();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Write(ex.Message, ToString() + Environment.NewLine);
            }
        }

    }
}
